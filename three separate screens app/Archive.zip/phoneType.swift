//
//  phoneType.swift
//  WA4_Chen_6479
//
//  Created by Hanru Chen on 10/4/23.
//

import Foundation

class phoneType {
    static let types = ["Cell", "Work", "Home"]
}
