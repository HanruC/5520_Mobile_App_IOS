//
//  NotesAPICalls.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/2/23.
//

import Foundation
import UIKit
import Alamofire

extension NoteViewController:NotesProtocol{
    func getAllNotes() {
        guard let token = UserDefaults.standard.string(forKey: "x-access-token") else {
            print("Error: token not found")
            return
        }
        
        if let url = URL(string: APIConfigs.baseURLNote + "getall") {
            AF.request(url, method: .get, headers: [
                "x-access-token":
                    token]).responseData(completionHandler: { response in
                        let status = response.response?.statusCode
                        switch response.result{
                        case .success(let data):
                            if let uwStatusCode = status{
                                switch uwStatusCode{
                                    case 200...299:
                                        print("success")
                                        self.notes.removeAll()
                                        let decoder = JSONDecoder()
                                        do{
                                            let receivedData =
                                                try decoder.decode(Notes.self, from: data)
                                            for item in receivedData.notes{
                                                self.notes.append(item)
                                            }
                                            self.mainScreen.tableViewNotes.reloadData()
                                        }catch{
                                            print("Decoding failed: \(error)")
                                        }
                                        break
                                    case 400...499:
                                        print(data)
                                        break
                                    
                                    default:
                                        print(data)
                                        break
                                    }
                                }
                                break
                        case .failure(let error):
                            print(error)
                            break
                            }
                        })
        }
    }

    
    func addANewNotes(note: String) {
        guard let token = UserDefaults.standard.string(forKey: "x-access-token") else {
            print("Error: token not found")
            return
        }
        if let url = URL(string: APIConfigs.baseURLNote + "post") {
            AF.request(url, method: .post, parameters: ["text": note], headers: [
                "x-access-token":
                    token]).responseData(completionHandler: { response in
                        let status = response.response?.statusCode
                        switch response.result {
                        case .success(let data):
                            if let uwStatusCode = status{
                                switch uwStatusCode{
                                case 200...299:
                                    self.getAllNotes()
                                    self.clearAddViewFields()
                                    break
                                    
                                case 400...499:
                                    print(data)
                                    break
                                    
                                default:
                                    print(data)
                                    break
                                }
                            }
                            break
                        case .failure(let error):
                            print(error)
                            break
                        }
                    })
        }
    }
    
    func deleteNotes(_id noteID: String) {
        guard let token = UserDefaults.standard.string(forKey: "x-access-token") else {
            print("Error: token not found")
            return
        }
        if let url = URL(string: APIConfigs.baseURLNote + "delete") {
            AF.request(url, method: .post, parameters: ["id": noteID], headers: [
                "x-access-token": token]).responseData(completionHandler: {
                    response in
                    let status = response.response?.statusCode
                    switch response.result{
                    case .success(let data):
                        if let uwStatusCode = status {
                            switch uwStatusCode {
                            case 200...299:
                                print("Note deleted")
                                self.getAllNotes()
                                break
                            case 400...499:
                                print(data)
                                break
                                
                            default:
                                print(data)
                                break
                            }
                        }
                        break
                    case .failure(let error):
                        print(error)
                        break
                    }
                })
        }
    }
    
}
