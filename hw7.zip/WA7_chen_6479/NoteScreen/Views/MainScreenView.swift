//
//  MainScreenView.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/2/23.
//

import UIKit

class MainScreenView: UIView, UITextViewDelegate {

    var tableViewNotes: UITableView!
    
    var bottomAddView: UIView!
    var textViewAddNotes: UITextView!
    var buttonAdd: UIButton!
    var placeholderLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        
        setupTableViewContacts()
        setupBottomAddView()
        setupTextViewAddNotes()
        setupButtonAdd()
        
        initConstraints()
    }
    
    func setupTableViewContacts(){
        tableViewNotes = UITableView()
        tableViewNotes.register(NotesTableViewCell.self, forCellReuseIdentifier: "names")
        tableViewNotes.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(tableViewNotes)
    }
    
    func setupBottomAddView(){
        bottomAddView = UIView()
        bottomAddView.backgroundColor = .white
        bottomAddView.layer.cornerRadius = 6
        bottomAddView.layer.shadowColor = UIColor.lightGray.cgColor
        bottomAddView.layer.shadowOffset = .zero
        bottomAddView.layer.shadowRadius = 4.0
        bottomAddView.layer.shadowOpacity = 0.7
        bottomAddView.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(bottomAddView)
    }

    
    func setupTextViewAddNotes() {
        textViewAddNotes = UITextView()
        textViewAddNotes.delegate = self
        textViewAddNotes.layer.cornerRadius = 8
        textViewAddNotes.layer.borderColor = UIColor.gray.withAlphaComponent(0.5).cgColor
        textViewAddNotes.layer.borderWidth = 0.5
        textViewAddNotes.translatesAutoresizingMaskIntoConstraints = false
        bottomAddView.addSubview(textViewAddNotes)
        
        placeholderLabel = UILabel()
        placeholderLabel.text = "Enter node..."
        placeholderLabel.font = UIFont.systemFont(ofSize: 16)
        placeholderLabel.textColor = UIColor.lightGray
        placeholderLabel.isHidden = !textViewAddNotes.text.isEmpty
        textViewAddNotes.addSubview(placeholderLabel)
        placeholderLabel.translatesAutoresizingMaskIntoConstraints = false
    }


    
    func setupButtonAdd(){
        buttonAdd = UIButton(type: .system)
        buttonAdd.setTitle("Add Nodes", for: .normal)
        buttonAdd.translatesAutoresizingMaskIntoConstraints = false
        bottomAddView.addSubview(buttonAdd)
    }
    
    func initConstraints() {
        NSLayoutConstraint.activate([
            // Constraints for tableViewNotes
            tableViewNotes.topAnchor.constraint(equalTo: self.safeAreaLayoutGuide.topAnchor),
            tableViewNotes.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor),
            tableViewNotes.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor),
            tableViewNotes.bottomAnchor.constraint(equalTo: bottomAddView.topAnchor),
            
            // Constraints for bottomAddView
            bottomAddView.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor),
            bottomAddView.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor),
            bottomAddView.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor),
            bottomAddView.heightAnchor.constraint(equalToConstant: 100),
            
            // Constraints for textViewAddNodes
            textViewAddNotes.topAnchor.constraint(equalTo: bottomAddView.topAnchor, constant: 10),
            textViewAddNotes.leadingAnchor.constraint(equalTo: bottomAddView.leadingAnchor, constant: 10),
            textViewAddNotes.trailingAnchor.constraint(equalTo: bottomAddView.trailingAnchor, constant: -10),
            textViewAddNotes.heightAnchor.constraint(equalToConstant: 40), // Fixed height for the text view
            
            // Constraints for placeholderLabel inside textView
            placeholderLabel.topAnchor.constraint(equalTo: textViewAddNotes.topAnchor),
            placeholderLabel.leadingAnchor.constraint(equalTo: textViewAddNotes.leadingAnchor, constant: 5),
            
            // Constraints for buttonAdd
            buttonAdd.topAnchor.constraint(equalTo: textViewAddNotes.bottomAnchor, constant: 10),
            buttonAdd.leadingAnchor.constraint(equalTo: bottomAddView.leadingAnchor, constant: 10),
            buttonAdd.trailingAnchor.constraint(equalTo: bottomAddView.trailingAnchor, constant: -10),
            buttonAdd.heightAnchor.constraint(equalToConstant: 40)
        ])
    }

    func textViewDidChange(_ textView: UITextView) {
        placeholderLabel.isHidden = !textView.text.isEmpty
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        placeholderLabel.isHidden = !textView.text.isEmpty
    }

        
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
