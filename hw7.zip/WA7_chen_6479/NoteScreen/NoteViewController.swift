//
//  NoteViewController.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/6/23.
//

import UIKit
import Alamofire

class NoteViewController: UIViewController {

    let mainScreen = MainScreenView()
    var notes = [Note]()
    
    override func loadView() {
        view = mainScreen
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Notes Adding JSON API"
        mainScreen.tableViewNotes.dataSource = self
        mainScreen.tableViewNotes.delegate = self
        mainScreen.tableViewNotes.separatorStyle = .none
        mainScreen.tableViewNotes.register(NotesTableViewCell.self, forCellReuseIdentifier: "names")
        getAllNotes()
        
        mainScreen.buttonAdd.addTarget(self, action: #selector(onButtonAddTapped), for: .touchUpInside)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutTapped))

        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Profile", style: .plain, target: self, action: #selector(showUserDetails))

    }
    
    @objc func showUserDetails() {
        NotificationCenter.default.post(name: .userDidRequestProfile, object: nil)
        
        let userDetailsVC = UserDetailViewController()
        self.navigationController?.pushViewController(userDetailsVC, animated: true)
    }


    @objc func logoutTapped() {
        UserDefaults.standard.removeObject(forKey: "x-access-token")
        
        NotificationCenter.default.post(name: .userDidLogoutNotification, object: nil)
        
        // Dismiss the NoteViewController
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func onButtonAddTapped() {
        guard let noteText = mainScreen.textViewAddNotes.text, !noteText.isEmpty else { return }
        addANewNotes(note: noteText)
    }
    
    func clearAddViewFields(){
        mainScreen.textViewAddNotes.text = ""
    }
}


extension NoteViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return notes.count
     }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "names", for: indexPath) as! NotesTableViewCell
        cell.labelName.text = notes[indexPath.row].text
        // Creating an accessory button
        let buttonOptions = UIButton(type: .system)
        buttonOptions.sizeToFit()
        buttonOptions.showsMenuAsPrimaryAction = true
        buttonOptions.setImage(UIImage(systemName: "slider.horizontal.3"), for: .normal)
        
        // Setting up menu for button options click
        buttonOptions.menu = UIMenu(title: "Delete?", children: [
            UIAction(title: "Delete", handler: { (_) in
                let noteID = self.notes[indexPath.row]._id
                self.deleteNotes(_id: noteID)
                self.notes.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
            })
        ])
        
        // Setting the button as an accessory of the cell
        cell.accessoryView = buttonOptions
        return cell
    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

