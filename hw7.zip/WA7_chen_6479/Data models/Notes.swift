//
//  Notes.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/2/23.
//

import Foundation


struct Notes: Codable {
    let notes: [Note]
}
