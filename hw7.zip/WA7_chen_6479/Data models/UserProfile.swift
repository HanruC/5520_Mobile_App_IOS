import Foundation

struct UserProfile: Codable {
    var _id: String
    var name: String
    var email: String
    var __v: Int
    
    init(_id: String, name: String, email: String, __v: Int) {
        self._id = _id
        self.name = name
        self.email = email
        self.__v = __v
    }
}
