//
//  Authentication.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/5/23.
//

import Foundation

struct Authentication: Codable{
    let token: String?
    
    init(token: String?) {
        self.token = token
    }
}
