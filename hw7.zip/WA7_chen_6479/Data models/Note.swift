//
//  Note.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/2/23.
//

import Foundation

struct Note: Codable {
    let userId: String
    let text: String?
    let _id: String
    let __v: Int
    
    init(userId: String, text: String, _id: String, __v: Int) {
        self.userId = userId
        self.text = text
        self._id = _id
        self.__v = __v 
    }
}
