import UIKit

class RegisterScreenView: UIView {

    var textFieldName: UITextField!
    var textFieldEmail: UITextField!
    var textFieldPassword: UITextField!
    var buttonRegister: UIButton!
    var buttonCancel: UIButton!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        
        setupTextFieldName()
        setupTextFieldEmail()
        setupTextFieldPassword()
        setupButtonRegister()
        setupButtonCancel()
        initConstraints()
    }
    
    func setupTextFieldName() {
        textFieldName = UITextField()
        textFieldName.placeholder = "Enter full name"
        textFieldName.borderStyle = .roundedRect
        textFieldName.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(textFieldName)
    }
    
    func setupTextFieldEmail() {
        textFieldEmail = UITextField()
        textFieldEmail.placeholder = "Enter email"
        textFieldEmail.borderStyle = .roundedRect
        textFieldEmail.keyboardType = .emailAddress
        textFieldEmail.autocapitalizationType = .none
        textFieldEmail.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(textFieldEmail)
    }
    
    func setupTextFieldPassword() {
        textFieldPassword = UITextField()
        textFieldPassword.placeholder = "Enter password"
        textFieldPassword.borderStyle = .roundedRect
        textFieldPassword.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(textFieldPassword)
    }
    
    func setupButtonRegister() {
        buttonRegister = UIButton()
        buttonRegister.setTitle("Register", for: .normal)
        buttonRegister.setTitleColor(.systemBlue, for: .normal)
        buttonRegister.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(buttonRegister)
    }
    
    func setupButtonCancel() {
        buttonCancel = UIButton()
        buttonCancel.setTitle("Cancel", for: .normal)
        buttonCancel.setTitleColor(.systemBlue, for: .normal)
        buttonCancel.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(buttonCancel)
    }

    func initConstraints() {
        NSLayoutConstraint.activate([
            textFieldName.centerXAnchor.constraint(equalTo: self.centerXAnchor),
            textFieldName.topAnchor.constraint(equalTo: self.safeAreaLayoutGuide.topAnchor, constant: 100),
            textFieldName.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20),
            textFieldName.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20),
            
            textFieldEmail.centerXAnchor.constraint(equalTo: self.centerXAnchor),
            textFieldEmail.topAnchor.constraint(equalTo: textFieldName.bottomAnchor, constant: 20),
            textFieldEmail.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20),
            textFieldEmail.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20),
            
            textFieldPassword.centerXAnchor.constraint(equalTo: self.centerXAnchor),
            textFieldPassword.topAnchor.constraint(equalTo: textFieldEmail.bottomAnchor, constant: 20),
            textFieldPassword.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20),
            textFieldPassword.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20),
            
            buttonRegister.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20),
            buttonRegister.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor, constant: -50),

            buttonCancel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20),
            buttonCancel.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor, constant: -50),
            
            // Set a fixed width for the buttons
            buttonRegister.widthAnchor.constraint(equalToConstant: 100),
            buttonCancel.widthAnchor.constraint(equalToConstant: 100),
            
            // Set the height for the buttons
            buttonRegister.heightAnchor.constraint(equalToConstant: 50),
            buttonCancel.heightAnchor.constraint(equalToConstant: 50)
        ])
    }


    
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
