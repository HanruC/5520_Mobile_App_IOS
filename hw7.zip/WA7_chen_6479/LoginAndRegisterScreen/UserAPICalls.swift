//
//  UserAPICalls.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/5/23.
//

import Foundation
import UIKit
import Alamofire

extension ViewController: UserProtocol {
    
    func Login(email: String, password: String) {
        let parameters: Parameters = [
            "email": email,
            "password": password
        ]
        if let url = URL(string: APIConfigs.baseURLAuthentication + "login") {
            // Ensure you encode the parameters using URLEncodedFormParameterEncoder
            AF.request(url, method: .post, parameters: parameters).responseData { response in
                let status = response.response?.statusCode
                
                switch response.result {
                case .success(let data):
                    if let uwStatusCode = status {
                        switch uwStatusCode {
                        case 200...299:
                            // Decode the JSON response to get the token
                            let decoder = JSONDecoder()
                            do {
                                let authResponse = try decoder.decode(Authentication.self, from: data)
                                // Check if the token is not nil
                                if let token = authResponse.token {
                                    // Save the token to UserDefaults
                                    UserDefaults.standard.set(token, forKey: "x-access-token")
                                    self.postLoginNotification()
                                  
                                } else {
                                    print("Error: Token not found in response.")
                                }
                            } catch {
                                print("Decoding failed: \(error)")
                            }
                        default:
                            // Handle other status codes as needed
                            print("Error: Received status code \(uwStatusCode)")
                        }
                    }
                case .failure(let error):
                    // Handle the failure case, including networking issues
                    print("Request failed with error: \(error.localizedDescription)")
                }
            }
        }
    }
    
    func getUserDetails() {
        guard let token = UserDefaults.standard.string(forKey: "x-access-token") else {
            print("Error: token not found")
            return
        }
        if let url = URL(string: APIConfigs.baseURLAuthentication + "me"){
            AF.request(url, method: .get, headers: [
                "x-access-token": token]).responseData(completionHandler: {
                    response in
                    let status = response.response?.statusCode
                    
                    switch response.result{
                    case .success(let data):
                        
                        if let uwStatusCode = status{
                            switch uwStatusCode{
                            case 200...299:
                                let decoder = JSONDecoder()
                                do{
                                    let userProfile = try
                                        decoder.decode(UserProfile.self, from: data)
                                    NotificationCenter.default.post(name: .userDidFetchProfile, object: nil, userInfo: ["userProfile": userProfile])
                                }catch{
                                    print("Decoding failed: \(error)")
                                }
                                break
                            case 400...499:
                                print(data)
                                break
                            default:
                                print(data)
                                break
                            }
                        }
                        break
                    case .failure(let error):
                        print(error)
                        break
                    }
                })
        }
    }
    
    
    
    func Register(name: String, email: String, password: String) {
        let parameters: [String: String] = [
            "name": name,
            "email": email,
            "password": password
        ]
        
        if let url = URL(string: APIConfigs.baseURLAuthentication + "register") {
            AF.request(url, method: .post, parameters: parameters).responseData { response in
                let status = response.response?.statusCode
                
                switch response.result {
                case .success(let data):
                    if let uwStatusCode = status {
                        switch uwStatusCode {
                        case 200...299:
                            let decoder = JSONDecoder()
                            do {
                                let authResponse = try decoder.decode(Authentication.self, from: data)
                                if let token = authResponse.token {
                                    UserDefaults.standard.set(token, forKey: "x-access-token")
                                    self.postLoginNotification()
                                }
                            } catch {
                                print("Decoding failed: \(error)")
                            }
                        case 400...499:
                            // Convert data to String to print a human-readable message
                            let errorMessage = String(data: data, encoding: .utf8) ?? "Unknown error occurred"
                            print("Client error: \(errorMessage)")
                        default:
                            // Convert data to String to print a human-readable message
                            let errorMessage = String(data: data, encoding: .utf8) ?? "Unknown error occurred"
                            print("Error with status code \(uwStatusCode): \(errorMessage)")
                        }
                    }
                case .failure(let error):
                    print("Request failed with error: \(error.localizedDescription)")
                }
            }
        } else {
            print("Invalid URL for registration")
        }
    }
}
