

import UIKit
import Alamofire

class ViewController: UIViewController {
    var loginView: LoginScreenView!
    var registerView: RegisterScreenView!
    var notificationCenter = NotificationCenter.default
    
    override func viewDidLoad() {
        super.viewDidLoad()
        notificationCenter.addObserver(self, selector: #selector(userDidLogin), name: .userDidLoginNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(userDidLogout), name: .userDidLogoutNotification, object: nil)
        determineInitialScreen()
        notificationCenter.addObserver(self, selector: #selector(handleProfileRequest), name: .userDidRequestProfile, object: nil)
    }
    
    @objc func handleProfileRequest() {
        getUserDetails()
    }
    
    func determineInitialScreen() {
        if UserDefaults.standard.string(forKey: "x-access-token") != nil {
            userDidLogin()
        }else {
            setupLoginView()
        }
    }
    
    @objc func userDidLogout() {
        setupLoginView()
    }
    
    @objc func userDidLogin() {
        let notesVC = NoteViewController()
        let navController = UINavigationController(rootViewController: notesVC)
        navController.modalPresentationStyle = .fullScreen
        present(navController, animated: true)
    }

    
    
    func postLoginNotification() {
        notificationCenter.post(name: .userDidLoginNotification, object: nil)
    }
    
    func setupLoginView() {
        loginView = LoginScreenView()
        view = loginView
        loginView.buttonLogin.addTarget(self, action: #selector(loginButtonTapped), for: .touchUpInside)
        loginView.buttonSignUp.addTarget(self, action: #selector(showRegisterView), for: .touchUpInside)
    }
    
    @objc func loginButtonTapped() {
        guard let email = loginView.textFieldEmail.text, !email.isEmpty,
              let password = loginView.textFieldPassword.text, !password.isEmpty else {
            presentAlert(withTitle: "Error", message: "Please fill in all fields.")
            return
        }
        
        Login(email: email, password: password)
    }
    
    
    @objc func showRegisterView() {
        registerView = RegisterScreenView()
        view = registerView
        registerView.buttonRegister.addTarget(self, action: #selector(registerButtonTapped), for: .touchUpInside)
        registerView.buttonCancel.addTarget(self, action: #selector(cancelButtonTapped), for: .touchUpInside)
    }
    
    @objc func cancelButtonTapped() {
        setupLoginView()
    }
    
    @objc func registerButtonTapped() {
        // Validate the input fields are not empty
        guard let name = registerView.textFieldName.text, !name.isEmpty,
              let email = registerView.textFieldEmail.text, !email.isEmpty,
              let password = registerView.textFieldPassword.text, !password.isEmpty else {
            // Present an alert if any fields are empty
            presentAlert(withTitle: "Error", message: "Please fill in all fields.")
            return
        }
        
        // Further validate the email is in the correct format
        guard isValidEmail(email) else {
            presentAlert(withTitle: "Error", message: "Please enter a valid email address.")
            return
        }
        
        // Call the Register API function
        Register(name: name, email: email, password: password)
    }

    // Helper function to present alerts
    func presentAlert(withTitle title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }

    // Helper function to validate email format
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: email)
    }
}


