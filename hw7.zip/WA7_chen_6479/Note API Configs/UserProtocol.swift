//
//  UserProtocol.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/5/23.
//

import Foundation

protocol UserProtocol{
    func Register(name: String, email: String, password: String)
    func Login(email: String, password: String)
    func getUserDetails()
}
