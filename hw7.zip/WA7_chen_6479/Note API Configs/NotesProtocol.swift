
import Foundation

protocol NotesProtocol{
    func getAllNotes()
    func addANewNotes(note: String)
    func deleteNotes(_id: String)
}
