struct APIConfigs {
    static let baseURLAuthentication = "http://apis.sakibnm.space:3000/api/auth/"
    static let baseURLNote = "http://apis.sakibnm.space:3000/api/note/"
}


