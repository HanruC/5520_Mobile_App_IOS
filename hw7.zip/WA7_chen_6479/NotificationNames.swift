//
//  NotificationNames.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/5/23.
//

import Foundation
extension Notification.Name {
    static let userDidLoginNotification = Notification.Name("userDidLoginNotification")
    static let userDidLogoutNotification = Notification.Name("userDidLogoutNotification")
    static let userDidFetchProfile = Notification.Name("userDidFetchProfile")
    static let userDidRequestProfile = Notification.Name("userDidRequestProfile")
}
