//
//  UserDetailViewController.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/6/23.
//

import UIKit
import Alamofire


class UserDetailViewController: UIViewController {

    var detailScreen = UserDetailView()
    var notificationCenter = NotificationCenter.default
    
    override func loadView() {
        view = detailScreen
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        notificationCenter.addObserver(self, selector: #selector(updateUserDetails(_:)), name: .userDidFetchProfile, object: nil)
    }
    
    @objc func updateUserDetails(_ notification: Notification) {
        if let userProfile = notification.userInfo?["userProfile"] as? UserProfile {
            // Update the detailScreen with the user profile details
            detailScreen.labelUserId.text = "User ID: \(userProfile._id)"
            detailScreen.labelName.text = "Name: \(userProfile.name)"
            detailScreen.labelEmail.text = "Email: \(userProfile.email)"
        }
    }
}
