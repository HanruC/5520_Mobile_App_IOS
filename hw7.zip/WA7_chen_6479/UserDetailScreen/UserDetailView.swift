//
//  UserDetailView.swift
//  WA7_chen_6479
//
//  Created by Hanru Chen on 11/6/23.
//

import UIKit

class UserDetailView: UIView {

    var labelUserId: UILabel!
    var labelName: UILabel!
    var labelEmail: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        setupLabelUserId()
        setupLabelName()
        setupLabelEmail()
        initConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupLabelUserId() {
        labelUserId = UILabel()
        labelUserId.font = UIFont.systemFont(ofSize: 16)
        labelUserId.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(labelUserId)
    }
    
    func setupLabelName() {
        labelName = UILabel()
        labelName.font = UIFont.systemFont(ofSize: 16)
        labelName.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(labelName)
    }
    
    func setupLabelEmail() {
        labelEmail = UILabel()
        labelEmail.font = UIFont.systemFont(ofSize: 16)
        labelEmail.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(labelEmail)
    }
    
    func initConstraints() {
        NSLayoutConstraint.activate([
            labelUserId.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 20),
            labelUserId.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            labelUserId.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            
            labelName.topAnchor.constraint(equalTo: labelUserId.bottomAnchor, constant: 20),
            labelName.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            labelName.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            
            labelEmail.topAnchor.constraint(equalTo: labelName.bottomAnchor, constant: 20),
            labelEmail.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            labelEmail.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20)
        ])
    }
}




